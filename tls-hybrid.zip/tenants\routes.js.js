const express = require("express");
const router = express.Router();

router.get("/", (req, res) => {
  res.json([
    { id: "tenant-1", name: "Demo Tenant 1" },
    { id: "tenant-2", name: "Demo Tenant 2" }
  ]);
});

module.exports = router;
