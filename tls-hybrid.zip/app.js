import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import apiRouter from "./auth/routes.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Serve frontend files
app.use(express.static(path.join(__dirname, "public")));

// API routes
app.use("/api", apiRouter);

// Fallback to index.html for SPA routing
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(process.env.PORT || 3000, () =>
  console.log("Hybrid app running on port", process.env.PORT || 3000)
);
