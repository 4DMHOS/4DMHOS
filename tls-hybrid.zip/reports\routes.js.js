const express = require("express");
const router = express.Router();
const db = require("../db");

// GET /reports
router.get("/", async (req, res) => {
  try {
    const reports = await db.query("SELECT * FROM reports ORDER BY created_at DESC");
    res.json(reports);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch reports" });
  }
});

module.exports = router;
