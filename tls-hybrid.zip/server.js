// server.js
// Entry point: import the Express app and start the HTTP server

const app = require("./app"); // assumes app.js exports the Express app
const http = require("http");

const PORT = process.env.PORT || 3000;

const server = http.createServer(app);

server.listen(PORT, () => {
  console.log(`TLS Reporting backend running on port ${PORT}`);
});

// Graceful shutdown
function shutdown(signal) {
  console.log(`Received ${signal}. Shutting down gracefully...`);
  server.close(err => {
    if (err) {
      console.error("Error during shutdown:", err);
      process.exit(1);
    }
    console.log("Shutdown complete.");
    process.exit(0);
  });

  // Force exit if shutdown takes too long
  setTimeout(() => {
    console.warn("Forcing shutdown after timeout.");
    process.exit(1);
  }, 10000).unref();
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
