const express = require("express");
const jwt = require("jsonwebtoken");

const router = express.Router();

router.post("/login", (req, res) => {
  const { email, tenantId } = req.body;

  if (!email || !tenantId) {
    return res.status(400).json({ error: "email and tenantId required" });
  }

  const token = jwt.sign(
    { email, tenantId },
    process.env.JWT_SECRET || "dev-secret",
    { expiresIn: "1h" }
  );

  res.json({ token });
});

module.exports = router;
